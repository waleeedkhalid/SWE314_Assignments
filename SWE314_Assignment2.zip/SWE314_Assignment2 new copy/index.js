const express = require("express");
const rateLimit = require('express-rate-limit');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

app.use(cookieParser());
app.use(express.static('public'));
app.use(bodyParser.json());
app.use(
  express.urlencoded({
    extended: true,
  })
);

// Define rate limiter for login attempts
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // Limit each IP to 5 login attempts per 15-minute window
  delayMs: 5000, // Introduce a 5-second delay between login attempts after reaching the limit
  message: "Too many login attempts from this IP, please try again later.", 
});



const passwordrouter = require('./routes/password');
app.use('/', loginLimiter, passwordrouter);

const OAuth2Router = require('./routes/auth');
app.use('/auth', OAuth2Router);

const DashboardRouter = require('./routes/dashboard');
app.use('/dashboard', DashboardRouter);

const webAuthnRouter = require('./routes/webauth');
app.use('/', webAuthnRouter);


app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});