const app = require('express').Router();

// app.get('/', (req, res) => {
//     res.send('Dashboard index');
// });


app.get('/', async (req, res) => {
    if (!req.cookies.GoogleToken) {
        return res.status(401).send('Unauthorized');
    }
    const accessToken = req.cookies.GoogleToken;

    const userInfoResponse = await fetch('https://www.googleapis.com/oauth2/v1/userinfo', {
        headers: { Authorization: `Bearer ${accessToken}` }
    });

    if (!userInfoResponse.ok) {
        return res.redirect('/?error=true');
    }

    const userData = await userInfoResponse.json();
    console.log(userData);

    // <h1>Welcome to the Dashboard</h1>
    // <h2>Email: ${userData.email}</h2>
    // <h2>Name: ${userData.name}</h2>
    // <img src="${userData.picture}" alt="Profile Picture" />
    // <a href="/auth/google/logout">Logout</a>
    
    res.send(`
        <div class="dashboard-container">
            <div class="sidebar">
                <div class="profile-section">
                    <img src="${userData.picture}" alt="Profile Picture" class="profile-image" onerror="this.src='./img/default-profile.png'"/>
                    <h2 class="user-name">${userData.name}</h2>
                    <p class="user-email">${userData.email}</p>
                    <p class="user-id">ID: ${userData.id}</p>
                    <p class="verification-status">
                        Email Status: ${userData.verified_email ? 
                            '<span class="verified">✓ Verified</span>' : 
                            '<span class="unverified">✗ Unverified</span>'}
                    </p>
                </div>
                <nav class="nav-menu">
                    <a href="#" class="nav-item active">Dashboard</a>
                    <a href="#" class="nav-item">Profile</a>
                    <a href="#" class="nav-item">Settings</a>
                    <a href="/auth/google/logout" class="nav-item logout">Logout</a>
                </nav>
            </div>
            <main class="main-content">
                <header class="content-header">
                    <h1>Welcome to Your Dashboard</h1>
                </header>
                <div class="dashboard-grid">
                    <div class="dashboard-card">
                        <h3>Quick Stats</h3>
                        <div class="stats-content">
                            <p>Welcome back! Your dashboard is ready.</p>
                        </div>
                    </div>
                    <div class="dashboard-card">
                        <h3>Recent Activity</h3>
                        <div class="activity-content">
                            <p>No recent activity to display.</p>
                        </div>
                    </div>
                </div>
            </main>
            <style>
                .dashboard-container {
                    display: flex;
                    min-height: 100vh;
                    background: #f5f6fa;
                    font-family: 'Segoe UI', sans-serif;
                }
                .sidebar {
                    width: 280px;
                    background: #fff;
                    box-shadow: 2px 0 5px rgba(0,0,0,0.1);
                    padding: 2rem;
                }
                .profile-section {
                    text-align: center;
                    padding-bottom: 2rem;
                    border-bottom: 1px solid #eee;
                }
                .profile-image {
                    width: 120px;
                    height: 120px;
                    border-radius: 50%;
                    margin-bottom: 1rem;
                    border: 3px solid #4a90e2;
                }
                .user-name {
                    margin: 0;
                    color: #2c3e50;
                    font-size: 1.2rem;
                }
                .user-email {
                    color: #7f8c8d;
                    margin: 0.5rem 0;
                }
                .nav-menu {
                    margin-top: 2rem;
                    display: flex;
                    flex-direction: column;
                    gap: 0.5rem;
                }
                .nav-item {
                    padding: 0.8rem 1rem;
                    color: #2c3e50;
                    text-decoration: none;
                    border-radius: 8px;
                    transition: all 0.3s ease;
                }
                .nav-item:hover, .nav-item.active {
                    background: #4a90e2;
                    color: white;
                }
                .nav-item.logout {
                    margin-top: auto;
                    color: #e74c3c;
                }
                .nav-item.logout:hover {
                    background: #e74c3c;
                    color: white;
                }
                .main-content {
                    flex: 1;
                    padding: 2rem;
                }
                .content-header {
                    margin-bottom: 2rem;
                }
                .content-header h1 {
                    color: #2c3e50;
                    margin: 0;
                }
                .dashboard-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                    gap: 2rem;
                }
                .dashboard-card {
                    background: white;
                    border-radius: 12px;
                    padding: 1.5rem;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                }
                .dashboard-card h3 {
                    margin: 0 0 1rem 0;
                    color: #2c3e50;
                }
            </style>
        </div>
    `);
});

app.get('/discord', async (req, res) => {
    if (!req.cookies.DiscordToken) {
        return res.status(401).send('Unauthorized');
    }
    const accessToken = req.cookies.DiscordToken;

    const userInfoResponse = await fetch('https://discord.com/api/v10/oauth2/@me', {
        headers: { Authorization: `Bearer ${accessToken}` }
    });

    if (!userInfoResponse.ok) {
        return res.redirect('/?error=true');
    }

    const userData = await userInfoResponse.json();

    console.log(userData);

    res.send(`
        <div class="dashboard-container">
            <div class="sidebar">
                <div class="profile-section">
                    <img src="https://cdn.discordapp.com/avatars/${userData.user.id}/${userData.user.avatar}" alt="Profile Picture" class="profile-image" onerror="this.src='./img/default-profile.png'"/>
                    <h2 class="user-name">${userData.user.global_name || userData.user.username}</h2>
                    <p class="user-id">ID: ${userData.user.id}</p>
                </div>
                <nav class="nav-menu">
                    <a href="#" class="nav-item active">Dashboard</a>
                    <a href="#" class="nav-item">Profile</a>
                    <a href="#" class="nav-item">Settings</a>
                    <a href="/auth/discord/logout" class="nav-item logout">Logout</a>
                </nav>
            </div>
            <main class="main-content">
                <header class="content-header">
                    <h1>Welcome to Your Discord Dashboard</h1>
                </header>
                <div class="dashboard-grid">
                    <div class="dashboard-card">
                        <h3>Quick Stats</h3>
                        <div class="stats-content">
                            <p>Welcome back! Your dashboard is ready.</p>
                        </div>
                    </div>
                    <div class="dashboard-card">
                        <h3>Recent Activity</h3>
                        <div class="activity-content">
                            <p>No recent activity to display.</p>
                        </div>
                    </div>
                </div>
            </main>
            <style>
                * {
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box; 
                }
                .dashboard-container {
                    display: flex;
                    min-height: 100vh;
                    background: #36393f;
                    font-family: 'Segoe UI', sans-serif;
                }
                .sidebar {
                    width: 280px;
                    background: #2f3136;
                    box-shadow: 2px 0 5px rgba(0,0,0,0.2);
                    padding: 2rem;
                }
                .profile-section {
                    text-align: center;
                    padding-bottom: 2rem;
                    border-bottom: 1px solid #40444b;
                }
                .profile-image {
                    width: 120px;
                    height: 120px;
                    border-radius: 50%;
                    margin-bottom: 1rem;
                    border: 3px solid #7289da;
                }
                .user-name {
                    margin: 0;
                    color: #ffffff;
                    font-size: 1.2rem;
                }
                .user-id {
                    color: #b9bbbe;
                    margin: 0.5rem 0;
                }
                .nav-menu {
                    margin-top: 2rem;
                    display: flex;
                    flex-direction: column;
                    gap: 0.5rem;
                }
                .nav-item {
                    padding: 0.8rem 1rem;
                    color: #dcddde;
                    text-decoration: none;
                    border-radius: 4px;
                    transition: all 0.3s ease;
                }
                .nav-item:hover, .nav-item.active {
                    background: #7289da;
                    color: white;
                }
                .nav-item.logout {
                    margin-top: auto;
                    color: #f04747;
                }
                .nav-item.logout:hover {
                    background: #f04747;
                    color: white;
                }
                .main-content {
                    flex: 1;
                    padding: 2rem;
                }
                .content-header {
                    margin-bottom: 2rem;
                }
                .content-header h1 {
                    color: #ffffff;
                    margin: 0;
                }
                .dashboard-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                    gap: 2rem;
                }
                .dashboard-card {
                    background: #2f3136;
                    border-radius: 8px;
                    padding: 1.5rem;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.2);
                }
                .dashboard-card h3 {
                    margin: 0 0 1rem 0;
                    color: #ffffff;
                }
                .stats-content p, .activity-content p {
                    color: #dcddde;
                }
            </style>
        </div>
    `);
});


module.exports = app;