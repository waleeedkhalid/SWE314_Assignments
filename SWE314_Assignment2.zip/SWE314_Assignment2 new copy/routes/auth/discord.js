// Discord OAuth2 Documentation
// https://discord.com/developers/docs/topics/oauth2

const app = require('express').Router();
const querystring = require('querystring');

const REDIRECT_URI_DISCORD = 'http://localhost:3000/auth/discord/callback';

require('dotenv').config();

const { DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET } = process.env;

app.get('/', (req, res) => {
    const authorizationUrl = 'https://discord.com/oauth2/authorize';
    const params = {
        client_id: DISCORD_CLIENT_ID,
        redirect_uri: REDIRECT_URI_DISCORD,
        response_type: 'code',
        scope: 'identify',
    };
    res.redirect(`${authorizationUrl}?${querystring.stringify(params)}`);
});

app.get('/callback', async (req, res) => {
    const code = req.query.code;
    if (!code) {
        return res.status(400).send('Authorization code is missing');
    }
    try {
        const tokenResponse = await fetch('https://discord.com/api/oauth2/token', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: querystring.stringify({
                code,
                client_id: DISCORD_CLIENT_ID,
                client_secret: DISCORD_CLIENT_SECRET,
                redirect_uri: REDIRECT_URI_DISCORD,
                grant_type: 'authorization_code'
            })
        });

        console.log(tokenResponse);

        if (!tokenResponse.ok) {
            throw new Error(JSON.stringify(await tokenResponse.json()));
        }

        const tokenData = await tokenResponse.json();
        const accessToken = tokenData.access_token;

        if (!accessToken) {
            throw new Error('Access token is missing in the response');
        }

        res.cookie('DiscordToken', accessToken, { httpOnly: true });
        res.redirect('/dashboard/discord');
    } catch (error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
});

app.get('/logout', (req, res) => {
    res.clearCookie('DiscordToken');
    res.redirect('/');
});


module.exports = app;