const app = require('express').Router();

// app.get('/', (req, res) => {
//     res.send('Dashboard index');
// });


app.get('/', async (req, res) => {
    if (!req.cookies.GoogleToken) {
        return res.status(401).send('Unauthorized');
    }
    const accessToken = req.cookies.GoogleToken;

    const userInfoResponse = await fetch('https://www.googleapis.com/oauth2/v1/userinfo', {
        headers: { Authorization: `Bearer ${accessToken}` }
    });

    if (!userInfoResponse.ok) {
        return res.redirect('/?error=true');
    }

    const userData = await userInfoResponse.json();
    console.log(userData);

    // <h1>Welcome to the Dashboard</h1>
    // <h2>Email: ${userData.email}</h2>
    // <h2>Name: ${userData.name}</h2>
    // <img src="${userData.picture}" alt="Profile Picture" />
    // <a href="/auth/google/logout">Logout</a>
    
    res.send(`
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Dashboard</title>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
        </head>
        <body>
            <div class="dashboard-container">
                <div class="sidebar">
                    <div class="profile-section">
                        <script>
                            function errorHandler(img) {
                                img.src = './img/logo.png';
                                document.getElementById('error-div').style.display = 'block';
                            }
                        </script>
                        <div id="error-div" style="display: none; color: red; font-size: 0.9rem; opacity: 0.8; margin-bottom: 1rem;">Error: Google CDN issue with profile picture</div>
                        <img src="${userData.picture.toString()}" alt="Profile Picture" class="profile-image" onerror="errorHandler(this)" />
                        <h2 class="user-name">${userData.name}</h2>
                        <p class="user-email">${userData.email}</p>
                        <p class="user-id">ID: ${userData.id}</p>
                        <p class="verification-status">
                            Email Status: ${userData.verified_email ? 
                                '<span class="verified">✓ Verified</span>' : 
                                '<span class="unverified">✗ Unverified</span>'}
                        </p>
                    </div>
                    <nav class="nav-menu">
                        <a href="#" class="nav-item active">Dashboard</a>
                        <a href="#" class="nav-item">Profile</a>
                        <a href="#" class="nav-item">Settings</a>
                        <a href="/auth/google/logout" class="nav-item logout">Logout</a>
                    </nav>
                </div>
                <main class="main-content">
                    <header class="content-header">
                        <h1>Welcome to Your Dashboard</h1>
                    </header>
                    <div class="dashboard-grid">
                        <div class="dashboard-card">
                            <h3>Quick Stats</h3>
                            <div class="stats-content">
                                <p>Welcome back! Your dashboard is ready.</p>
                            </div>
                        </div>
                        <div class="dashboard-card">
                            <h3>Database Views</h3>
                            <div class="activity-content">
                                <div class="database-links">
                                    <a href="/users" target="_blank" class="db-link">
                                        <i class="fas fa-users"></i>
                                        <span class="link-text">Users Database</span>
                                        <span class="link-icon">↗</span>
                                    </a>
                                    <p class="note">
                                        Note: If the password and salt columns are null for a user, it means they registered using a passkey. In the future, we can add functionality to allow them to add a password from the dashboard.
                                    </p>
                                    <style>
                                        .note {
                                            color: #2c3e50;
                                            font-size: 0.9rem;
                                            opacity: 0.8;
                                        }
                                    </style>
                                    <a href="/passkeys" target="_blank" class="db-link">
                                        <i class="fas fa-key"></i>
                                        <span class="link-text">Passkeys Database</span>
                                        <span class="link-icon">↗</span>
                                    </a>
                                    <style>
                                        .database-links {
                                            display: flex;
                                            flex-direction: column;
                                            gap: 1rem;
                                            padding: 1rem;
                                        }
                                        .db-link {
                                            display: flex;
                                            align-items: center;
                                            padding: 1rem;
                                            background: #4a90e2;
                                            color: white;
                                            text-decoration: none;
                                            border-radius: 8px;
                                            transition: all 0.3s ease;
                                            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                                        }
                                        .db-link:hover {
                                            background: #357abd;
                                            transform: translateY(-2px);
                                            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
                                        }
                                        .db-link i {
                                            margin-right: 1rem;
                                            font-size: 1.2rem;
                                        }
                                        .link-text {
                                            flex: 1;
                                            font-weight: 500;
                                        }
                                        .link-icon {
                                            margin-left: 0.5rem;
                                            font-size: 0.9rem;
                                            opacity: 0.8;
                                        }
                                    </style>
                                </div>
                                <style>
                                    .database-links {
                                        display: flex;
                                        flex-direction: column;
                                        gap: 1rem;
                                    }
                                    .db-link {
                                        padding: 0.5rem 1rem;
                                        background: #4a90e2;
                                        color: white;
                                        text-decoration: none;
                                        border-radius: 4px;
                                        transition: background 0.3s ease;
                                    }
                                    .db-link:hover {
                                        background: #357abd;
                                    }
                                </style>
                            </div>
                        </div>
                    </div>
                </main>
                <style>
                    .dashboard-container {
                        display: flex;
                        min-height: 100vh;
                        background: #f5f6fa;
                        font-family: 'Segoe UI', sans-serif;
                    }
                    .sidebar {
                        width: 280px;
                        background: #fff;
                        box-shadow: 2px 0 5px rgba(0,0,0,0.1);
                        padding: 2rem;
                    }
                    .profile-section {
                        text-align: center;
                        padding-bottom: 2rem;
                        border-bottom: 1px solid #eee;
                    }
                    .profile-image {
                        width: 120px;
                        height: 120px;
                        border-radius: 50%;
                        margin-bottom: 1rem;
                        border: 3px solid #4a90e2;
                        object-fit: cover;
                        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
                        transition: transform 0.3s ease, border-color 0.3s ease;
                    }
                    .profile-image:hover {
                        transform: scale(1.05);
                        border-color: #2171cd;
                    }
                    .user-name {
                        margin: 0;
                        color: #2c3e50;
                        font-size: 1.2rem;
                    }
                    .user-email {
                        color: #7f8c8d;
                        margin: 0.5rem 0;
                    }
                    .nav-menu {
                        margin-top: 2rem;
                        display: flex;
                        flex-direction: column;
                        gap: 0.5rem;
                    }
                    .nav-item {
                        padding: 0.8rem 1rem;
                        color: #2c3e50;
                        text-decoration: none;
                        border-radius: 8px;
                        transition: all 0.3s ease;
                    }
                    .nav-item:hover, .nav-item.active {
                        background: #4a90e2;
                        color: white;
                    }
                    .nav-item.logout {
                        margin-top: auto;
                        color: #e74c3c;
                    }
                    .nav-item.logout:hover {
                        background: #e74c3c;
                        color: white;
                    }
                    .main-content {
                        flex: 1;
                        padding: 2rem;
                    }
                    .content-header {
                        margin-bottom: 2rem;
                    }
                    .content-header h1 {
                        color: #2c3e50;
                        margin: 0;
                    }
                    .dashboard-grid {
                        display: grid;
                        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                        gap: 2rem;
                    }
                    .dashboard-card {
                        background: white;
                        border-radius: 12px;
                        padding: 1.5rem;
                        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                    }
                    .dashboard-card h3 {
                        margin: 0 0 1rem 0;
                        color: #2c3e50;
                    }
                </style>
            </div>
        </body>
        </html>
    `);
});

app.get('/discord', async (req, res) => {
    if (!req.cookies.DiscordToken) {
        return res.status(401).send('Unauthorized');
    }
    const accessToken = req.cookies.DiscordToken;

    const userInfoResponse = await fetch('https://discord.com/api/v10/oauth2/@me', {
        headers: { Authorization: `Bearer ${accessToken}` }
    });

    if (!userInfoResponse.ok) {
        return res.redirect('/?error=true');
    }

    const userData = await userInfoResponse.json();

    console.log(userData);

    res.send(`
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Discord Dashboard</title>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
        </head>
        <body>
            <div class="dashboard-container">
                <div class="sidebar">
                    <div class="profile-section">
                        <img src="https://cdn.discordapp.com/avatars/${userData.user.id}/${userData.user.avatar}" alt="Profile Picture" class="profile-image" onerror="this.src='./img/logo.png'"/>
                        <h2 class="user-name">${userData.user.global_name || userData.user.username}</h2>
                        <p class="user-id">ID: ${userData.user.id}</p>
                    </div>
                    <nav class="nav-menu">
                        <a href="#" class="nav-item active">Dashboard</a>
                        <a href="#" class="nav-item">Profile</a>
                        <a href="#" class="nav-item">Settings</a>
                        <a href="/auth/discord/logout" class="nav-item logout">Logout</a>
                    </nav>
                </div>
                <main class="main-content">
                    <header class="content-header">
                        <h1>Welcome to Your Discord Dashboard</h1>
                    </header>
                    <div class="dashboard-grid">
                        <div class="dashboard-card">
                            <h3>Quick Stats</h3>
                            <div class="stats-content">
                                <p>Welcome back! Your dashboard is ready.</p>
                            </div>
                        </div>
                        <div class="dashboard-card">
                            <div class="activity-content">
                                <h3>Database Views</h3>
                                <div class="database-links">
                                    <a href="/users" target="_blank" class="db-link">
                                        <i class="fas fa-users"></i>
                                        <span class="link-text">View User Database</span>
                                        <span class="link-icon">↗</span>
                                    </a>
                                    <a href="/passkeys" target="_blank" class="db-link">
                                        <i class="fas fa-key"></i>
                                        <span class="link-text">View Passkeys Database</span>
                                        <span class="link-icon">↗</span>
                                    </a>
                                </div>
                                <style>
                                    .database-links {
                                        display: flex;
                                        flex-direction: column;
                                        gap: 1rem;
                                        padding: 1rem;
                                    }
                                    .db-link {
                                        display: flex;
                                        align-items: center;
                                        padding: 1rem;
                                        background: #4a90e2;
                                        color: white;
                                        text-decoration: none;
                                        border-radius: 8px;
                                        transition: all 0.3s ease;
                                        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                                    }
                                    .db-link:hover {
                                        background: #357abd;
                                        transform: translateY(-2px);
                                        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
                                    }
                                    .db-link i {
                                        margin-right: 1rem;
                                        font-size: 1.2rem;
                                    }
                                    .link-text {
                                        flex: 1;
                                        font-weight: 500;
                                    }
                                </style>
                            </div>
                        </div>
                    </div>
                </main>
                <style>
                    * {
                        margin: 0;
                        padding: 0;
                        box-sizing: border-box; 
                    }
                    .dashboard-container {
                        display: flex;
                        min-height: 100vh;
                        background: #36393f;
                        font-family: 'Segoe UI', sans-serif;
                    }
                    .sidebar {
                        width: 280px;
                        background: #2f3136;
                        box-shadow: 2px 0 5px rgba(0,0,0,0.2);
                        padding: 2rem;
                    }
                    .profile-section {
                        text-align: center;
                        padding-bottom: 2rem;
                        border-bottom: 1px solid #40444b;
                    }
                    .profile-image {
                        width: 120px;
                        height: 120px;
                        border-radius: 50%;
                        margin-bottom: 1rem;
                        border: 3px solid #4a90e2;
                    }
                    .profile-image {
                        transition: all 0.3s ease;
                    }
                    .profile-image:hover {
                        transform: scale(1.05);
                        border-color: #2171cd;
                    }
                    .user-name {
                        margin: 0;
                        color: #ffffff;
                        font-size: 1.2rem;
                    }
                    .user-id {
                        color: #b9bbbe;
                        margin: 0.5rem 0;
                    }
                    .nav-menu {
                        margin-top: 2rem;
                        display: flex;
                        flex-direction: column;
                        gap: 0.5rem;
                    }
                    .nav-item {
                        padding: 0.8rem 1rem;
                        color: #dcddde;
                        text-decoration: none;
                        border-radius: 4px;
                        transition: all 0.3s ease;
                    }
                    .nav-item:hover, .nav-item.active {
                        background: #7289da;
                        color: white;
                    }
                    .nav-item.logout {
                        margin-top: auto;
                        color: #f04747;
                    }
                    .nav-item.logout:hover {
                        background: #f04747;
                        color: white;
                    }
                    .main-content {
                        flex: 1;
                        padding: 2rem;
                    }
                    .content-header {
                        margin-bottom: 2rem;
                    }
                    .content-header h1 {
                        color: #ffffff;
                        margin: 0;
                    }
                    .dashboard-grid {
                        display: grid;
                        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                        gap: 2rem;
                    }
                    .dashboard-card {
                        background: #2f3136;
                        border-radius: 8px;
                        padding: 1.5rem;
                        box-shadow: 0 2px 4px rgba(0,0,0,0.2);
                    }
                    .dashboard-card h3 {
                        margin: 0 0 1rem 0;
                        color: #ffffff;
                    }
                    .stats-content p, .activity-content p {
                        color: #dcddde;
                    }
                </style>
            </div>
        </body>
        </html>
    `);
});


module.exports = app;