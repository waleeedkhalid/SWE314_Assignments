const app = require('express').Router();
const database = require("../../database/database.js"); 
const { authenticator } = require('otplib');
const QRCode = require('qrcode');
const { decrypt, encrypt } = require('../../encrypt.js');

app.post('/login', (req, res) => {
  const { username, password, otp } = req.body;

  const user = {
    username: username,
    passwordToCheck: password,
    otp
  }

  database.authenticate(user)
  .then((result) => 
  {
    if(result){
      const userSecret = result.twoFactorSecret;
      if(!userSecret) {
        // res.json(result);
        res.send(`
          <html>
  <head>
    <style>
      body {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100vh;
        margin: 0;
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
      }
      .profile-container {
        background-color: #fff;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        width: 300px;
        text-align: center;
      }
      .profile-header {
        font-size: 1.5em;
        margin-bottom: 10px;
        color: #333;
      }
      .profile-details {
        margin: 10px 0;
        color: #555;
        word-wrap: break-word;
      }
      .profile-value {
        font-weight: bold;
        color: #0066cc;
      }
    </style>
  </head>
  <body>
    <div class="profile-container">
      <div class="profile-header">Username: <span class="profile-value">${result.username}</span>!</div>
      <div class="profile-details">Password (Hashed SHA-3): <span class="profile-value">${result.password}</span></div>
      <div class="profile-details">Salt: <span class="profile-value">${result.salt}</span></div>
      <div class="profile-details">Two Factor Secret (Encrypted): <span class="profile-value">${result.twoFactorSecret}</span></div>
    </div>
  </body>
</html>
          `)
        return;
      }
      // Decrypt the stored secret for OTP verification
      const isValid = authenticator.check(otp, decrypt(userSecret));

      if (isValid) {
         //res.json(result);
        res.send(`
          <html>
  <head>
    <style>
      body {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100vh;
        margin: 0;
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
      }
      .profile-container {
        background-color: #fff;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        width: 300px;
        text-align: center;
      }
      .profile-header {
        font-size: 1.5em;
        margin-bottom: 10px;
        color: #333;
      }
      .profile-details {
        margin: 10px 0;
        color: #555;
        word-wrap: break-word;
      }
    </style>
  </head>
  <body>
    <div class="profile-container">
      <div class="profile-header">Username: ${result.username}</div>
      <div class="profile-details">Password(Hashed SHA-3): ${result.password}</div>
      <div class="profile-details">Salt: ${result.salt}</div>
      <div class="profile-details">Two Factor Secret(Encrypted): ${result.twoFactorSecret}</div>
    </div>
  </body>
</html>

          `)
      } else {
        res.redirect('/?otpfailure=true'); // OTP is Incorrect.
      }
    }
    else{
      res.redirect('/?error=true'); // Username or password is Incorrect.
    }
  })
  .catch((err) => res.redirect('/?error=true')
  )
});

// app.post('/oldlogin', async (req, res) => {
//   const { username, password, otp } = req.body;

//   const user = {
//       username,
//       passwordToCheck: password,
//       otp
//   };

//   try {
//       const result = await database.authenticate(user);
//       if (result) {
//           const userSecret = result.twoFactorSecret;
//           if (!userSecret) {
//               // No 2FA required, return the result (user data)
//               return res.json({ success: true, user: result });
//           }

//           // 2FA is enabled, check OTP
//           if (!otp) {
//               // If OTP is not provided, return an error to prompt the frontend to show OTP field
//               return res.json({ error: 'otp' });
//           }

//           const isValidOtp = authenticator.check(otp, decrypt(userSecret));
//           if (isValidOtp) {
//               // OTP is valid, return the user data
//               return res.json({ success: true, user: result });
//           } else {
//               // OTP is invalid
//               return res.json({ error: 'otp' });
//           }
//       } else {
//           // Password or username is incorrect
//           return res.json({ error: 'password' });
//       }
//   } catch (err) {
//       console.error(err);
//       return res.json({ error: 'server' });
//   }
// });

app.post('/submitSignup', async (req, res) => {
  const { username, password } = req.body;
  console.log(username, password);

  try {
    const userSecret = authenticator.generateSecret();
    const encryptedSecret = encrypt(userSecret);

    const user = {
      username: username,
      password: password,
      secret: encryptedSecret
    };

    const result = await database.signup(user);

    if (!result.success) {
      // Render an HTML page that displays the error message
      res.send(`
        <html>
          <head>
            <style>
              body {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                height: 100vh;
                margin: 0;
                font-family: Arial, sans-serif;
                background-color: #f5f5f5;
              }
              .error {
                color: red;
                margin-bottom: 20px;
              }
              a {
                padding: 10px 20px;
                background-color: #007bff;
                color: white;
                text-decoration: none;
                border-radius: 5px;
                transition: background-color 0.3s;
              }
              a:hover {
                background-color: #0056b3;
              }
            </style>
          </head>
          <body>
            <div class="error">Error: ${result.message}</div>
            <a href="/?register=true">Go Back to Sign Up</a>
          </body>
        </html>
      `);
      return;
    }

    // Generate QR code and send success HTML page
    QRCode.toDataURL(authenticator.keyuri(username, 'SWE314_Assignment1', userSecret), (err, imageUrl) => {
      if (err) {
        console.error('Error generating QR code', err);
        res.status(500).json({ message: 'Error generating QR code' });
      } else {
        res.send(`
          <html>
            <head>
              <style>
                body {
                  display: flex;
                  flex-direction: column;
                  align-items: center;
                  justify-content: center;
                  height: 100vh;
                  margin: 0;
                  font-family: Arial, sans-serif;
                  background-color: #f5f5f5;
                }
                h2 {
                  color: #333;
                }
                p {
                  color: #666;
                }
                img {
                  margin: 20px 0;
                  border: 2px solid #ddd;
                  border-radius: 8px;
                }
                a {
                  padding: 10px 20px;
                  background-color: #007bff;
                  color: white;
                  text-decoration: none;
                  border-radius: 5px;
                  transition: background-color 0.3s;
                }
                a:hover {
                  background-color: #0056b3;
                }
              </style>
            </head>
            <body>
              <h2>User created successfully!</h2>
              <p>Scan the QR Code below to activate 2FA (Two Factor Authentication)</p>
              <img src="${imageUrl}" alt="QR Code">
              <a href="/?login=true">Login</a>
            </body>
          </html>
        `);
      }
    });

  } catch (err) {
    console.error('Error during signup:', err);
    res.status(500).send(`
      <html>
        <head>
          <style>
            body {
              display: flex;
              flex-direction: column;
              align-items: center;
              justify-content: center;
              height: 100vh;
              margin: 0;
              font-family: Arial, sans-serif;
              background-color: #f5f5f5;
            }
            .error {
              color: red;
              margin-bottom: 20px;
            }
            a {
              padding: 10px 20px;
              background-color: #007bff;
              color: white;
              text-decoration: none;
              border-radius: 5px;
              transition: background-color 0.3s;
            }
            a:hover {
              background-color: #0056b3;
            }
          </style>
        </head>
        <body>
          <div class="error">Server error during signup. Please try again later.</div>
          <a href="/?register=true">Go Back to Register</a>
        </body>
      </html>
    `);
  }
});

app.get('/users', async (req, res) => {
  await database.users()
  .then((result) => res.json(result))
  .catch((err) => res.json(err));
});


module.exports = app;