const router = require('express').Router();
const GoogleRouter = require('./google');
const DiscordRouter = require('./discord');

router.use('/discord', DiscordRouter);
router.use('/google', GoogleRouter);
router.get('/', (req, res) => {
  res.send('Auth index');
});

module.exports = router;