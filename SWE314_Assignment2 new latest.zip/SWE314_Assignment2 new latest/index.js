const express = require("express");
const rateLimit = require('express-rate-limit');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

app.use(cookieParser());
app.use(express.static('public'));
app.use(bodyParser.json());
app.use(
  express.urlencoded({
    extended: true,
  })
);

// Define rate limiter for login attempts to prevent brute force attacks
const loginLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 1000, // Limit to 5 attempts per hour to prevent brute force
  delayMs: 0, // No delay to ensure immediate response for legitimate users
  message: "Excessive login attempts detected. Please try again later.", 
});


const passwordrouter = require('./routes/password');
app.use('/', loginLimiter, passwordrouter);

const OAuth2Router = require('./routes/auth');
app.use('/auth', OAuth2Router);

const DashboardRouter = require('./routes/dashboard');
app.use('/dashboard', DashboardRouter);

const webAuthnRouter = require('./routes/webauth');
app.use('/', webAuthnRouter);


app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});