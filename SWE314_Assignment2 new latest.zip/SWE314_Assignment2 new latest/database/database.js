const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.resolve(__dirname, 'database.db');

const crypto = require('node:crypto');

function validatePassword(password) {
  const regex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{13,}$/;

  if (!regex.test(password)) {
    console.log("Password must be at least 13 characters long and include both letters and numbers.");
    return false;
  }
  return true;
}

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.createHmac("sha512", salt).update(password).digest("hex");

  return { salt, hash };
}

function verifyPassword(storedSalt, storedHash, password) {
  const hashToCheck = crypto
    .createHmac("sha512", storedSalt)
    .update(password)
    .digest("hex");

  return hashToCheck === storedHash;
}
// Input validation function to ensure username and password contain only expected characters
const validateInput = (input) => {
  const regex = /^[a-zA-Z0-9_]*$/;// Only alphanumeric characters and underscores allowed
  return regex.test(input);
}

const users = async () => {
  try {
    const db = await dbinit();
    const sql = `SELECT * FROM users`;

    return new Promise((resolve, reject) =>
      db.all(sql, [], (err, rows) => {
        db.close();
        return resolve(rows);
      }))
  } catch (err) {
    console.error(err);
  }
};
// Authentication function with input validation

const authentication = async ({ username, passwordToCheck }) => {
  try {

    if (!validateInput(username) || !validateInput(passwordToCheck)) {
      console.log("Invalid input: only alphanumeric characters and underscore are allowed.");
      return null;
    }

    const db = await dbinit();
    const sql = `SELECT * FROM users WHERE username = ?`;

    return new Promise((resolve, reject) =>
      db.get(sql, [username], (err, row) => {
        db.close();
        if (err) {
          return reject(err);
        }

        // no user found
        if (!row) {
          return resolve(null);
        }

        console.log(row);
        if (!row.salt || !row.password) return resolve(null);
        const isPasswordValid = verifyPassword(row.salt, row.password, passwordToCheck);
        if (isPasswordValid) {
          return resolve(row);
        }

        return resolve(null);
      }
      )
    )
  } catch (err) {
    console.error(err);
  }
};

const signup = async ({ username, password, secret }) => {
  // Validate username
  if (!validateInput(username)) {
    console.log("Invalid input: only alphanumeric characters and underscores are allowed.");
    return { success: false, message: "Invalid username: only alphanumeric characters and underscores are allowed." };
  }

  // Validate password
  if (!validatePassword(password)) {
    console.log("Invalid password: Password must contain at least one number, one uppercase letter, one lowercase letter, and be at least 13 characters long.");
    return { success: false, message: "Invalid password: Must contain at least one number, one uppercase letter, one lowercase letter, and be at least 13 characters long." };
  }

  const db = await dbinit();
  const { salt, hash } = hashPassword(password);

  const sql = `INSERT INTO users (username, password, salt, twoFactorSecret) VALUES (?, ?, ?, ?)`;

  return new Promise((resolve, reject) => {
    db.run(sql, [username, hash, salt, secret], function (err) {
      db.close();
      if (err) {
        if (err.code === 'SQLITE_CONSTRAINT') {
          console.error('Username already exists.');
          return resolve({ success: false, message: "Username already exists." });
        }
        return reject(err); // Reject for any other database error
      }
      resolve({ success: true, message: "User created successfully." });
    });
  });
};

const dbinit = async () => {
  try {
    const db = await new sqlite3.Database(dbPath);
    const sql = `CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      password TEXT,
      salt TEXT,
      twoFactorSecret TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`;
    const sql2 = `CREATE TABLE IF NOT EXISTS passkeys (
      cred_id TEXT PRIMARY KEY,
      cred_public_key BLOB NOT NULL,
      internal_user_id INTEGER NOT NULL,
      webauthn_user_id TEXT NOT NULL,
      counter INTEGER DEFAULT 0,
      backup_eligible BOOLEAN DEFAULT FALSE,
      backup_status BOOLEAN DEFAULT FALSE,
      transports TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      last_used TIMESTAMP,
      FOREIGN KEY (internal_user_id) REFERENCES users (id)
    );`
    db.run(sql);
    db.run(sql2);
    return db;
  }
  catch (err) {
    console.log(err);
    throw err;
  }
};

const addUser = async (username, password, secret) => {
  const db = await dbinit();
  const { salt, hash } = hashPassword(password);
  const sql = `INSERT INTO users (username, password, salt, twoFactorSecret) VALUES (?, ?, ?, ?)`;

  return new Promise((resolve, reject) => {
    db.run(sql, [username, hash, salt, secret], function (err) {
      db.close();
      if (err) {
        if (err.code === 'SQLITE_CONSTRAINT') {
          console.error('Username already exists.');
          return resolve({ success: false, message: "Username already exists." });
        }
        return reject(err); // Reject for any other database error
      }
      resolve({ success: true, message: "User created successfully." });
    });
  });
};

// WEBAUTHN FUNCTIONS

const getPasskeys = async () => {
  try {
    const db = await dbinit();
    const sql = `SELECT * FROM passkeys`;

    const rows = await new Promise((resolve, reject) => {
      db.all(sql, [], (err, rows) => {
        if (err) {
          reject(err);
        }
        resolve(rows);
      });
    });

    db.close();
    return rows;

  } catch (err) {
    console.error('Error getting passkeys:', err);
    throw err;
  }
}

const getUserPasskeys = async (username) => {
  try {
    const db = await dbinit();
    const user = await getUserFromDB(username);
    if (!user) {
      db.close();
      return undefined;
    }
    const sql = `SELECT * FROM passkeys WHERE internal_user_id = ?`;
    
    const rows = await new Promise((resolve, reject) => {
      db.all(sql, [user.id], (err, rows) => {
        if (err) {
          reject(err);
        }
        resolve(rows);
      });
    });
    
    db.close();
    return rows;
    
  } catch (err) {
    console.error('Error getting user passkeys:', err);
    throw err;
  }
};

const saveNewPasskeyInDB = async (passkey) => {
  const db = await dbinit();
  let user = await getUserFromDB(passkey.user.name);
  if (!user) {
    // save user
    await addUserPasskey(passkey.user.name);
    user = await getUserFromDB(passkey.user.name);
    console.log('user', user);
  }
  const sql = `
    INSERT INTO passkeys (
      cred_id,
      cred_public_key, 
      internal_user_id,
      webauthn_user_id,
      counter,
      backup_eligible,
      backup_status,
      transports,
      created_at,
      last_used
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`;

  return new Promise((resolve, reject) => {
    db.run(sql, [
      passkey.id,
      passkey.publicKey,
      user.id,
      passkey.webAuthnUserID, 
      passkey.counter,
      passkey.backupEligible,
      passkey.backedUp,
      JSON.stringify(passkey.transports),
      new Date().toISOString(),
      new Date().toISOString()
    ], function(err) {
      db.close();
      if (err) {
        return reject(err);
      }
      return resolve({ success: true, message: "Passkey saved successfully." });
    });
  });
};

const addUserPasskey = async (username) => {
  const db = await dbinit();
  const sql = `
    INSERT INTO users (
      username,
      created_at
    ) VALUES (
      ?,
      CURRENT_TIMESTAMP
    )`;

  return new Promise((resolve, reject) => {
    db.run(sql, [username], function (err) {
      db.close();
      if (err) {
        if (err.code === 'SQLITE_CONSTRAINT') {
          console.error('Username already exists.');
          return resolve({ success: false, message: "Username already exists." });
        }
        return reject(err); // Reject for any other database error
      }
      resolve({ success: true, message: "User created successfully." });
    });
  });
};

const getUserFromDB = async (username) => {
  const db = await dbinit();
  const sql = `SELECT * FROM users WHERE username = ?`;

  return new Promise((resolve, reject) => {
    db.get(sql, [username], (err, row) => {
      if (err) {
        return reject(err); 
      }
      if (!row) {
        return resolve(null);
      }
      db.close();
      return resolve(row);
    });
  });
};

const saveUpdatedCounter = async (passkey, newCounter) => {
  const db = await dbinit();
  await db.run(`
        UPDATE passkeys
        SET counter = ?, last_used = ?
        WHERE cred_id = ?
    `, [newCounter, new Date().toISOString(), passkey.id]);
  await db.close();
};

module.exports = {
  authenticate: authentication,
  signup: signup,
  users,
  getPasskeys,
  addUser,
  getUserPasskeys,
  saveNewPasskeyInDB,
  getUserFromDB,
  saveUpdatedCounter
};